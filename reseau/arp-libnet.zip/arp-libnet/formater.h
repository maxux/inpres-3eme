#ifndef FORMATER_H
	#define FORMATER_H
	
	char *format_ipMD(unsigned char *data, char *str);
	char *format_macMD(unsigned char *data, char *str);
#endif
